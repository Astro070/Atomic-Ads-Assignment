import { alerts } from '@/lib/data';
import { AlertsTable } from '@/components/admin/alerts-table';
import { Button } from '@/components/ui/button';
import { CreateAlertDialog } from '@/components/admin/create-alert-dialog';

export default function AdminDashboardPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Alerts Dashboard</h1>
          <p className="text-muted-foreground">
            Manage and monitor all alerts.
          </p>
        </div>
        <CreateAlertDialog />
      </div>

      <AlertsTable alerts={alerts} />
    </div>
  );
}
