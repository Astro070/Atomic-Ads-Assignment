import { alerts } from '@/lib/data';
import { AlertsTable } from '@/components/admin/alerts-table';
import { CreateAlertDialog } from '@/components/admin/create-alert-dialog';

export default function AdminAlertsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Manage Alerts</h1>
          <p className="text-muted-foreground">
            Create, update, and archive alerts.
          </p>
        </div>
        <CreateAlertDialog />
      </div>

      <AlertsTable alerts={alerts} />
    </div>
  );
}
