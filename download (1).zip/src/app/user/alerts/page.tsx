import { UserAlertsList } from '@/components/user/user-alerts-list';
import { alerts, users } from '@/lib/data';
import type { Alert } from '@/lib/types';

function getVisibleAlertsForUser(userId: string): Alert[] {
  const user = users.find((u) => u.id === userId);
  if (!user) return [];

  return alerts.filter((alert) => {
    if (alert.status !== 'active') return false;

    switch (alert.visibilityScope) {
      case 'Organization':
        return true;
      case 'Team':
        return alert.visibilityTargets.includes(user.teamId);
      case 'User':
        return alert.visibilityTargets.includes(user.id);
      default:
        return false;
    }
  });
}

export default function UserAlertsPage() {
  // Mocking the logged-in user as 'Alice' (user-1)
  const userAlerts = getVisibleAlertsForUser('user-1');

  return (
    <div className="space-y-6">
       <div>
          <h1 className="text-2xl font-bold tracking-tight">View Alerts</h1>
          <p className="text-muted-foreground">
            Manage your alerts below.
          </p>
        </div>
      <UserAlertsList alerts={userAlerts} />
    </div>
  );
}
