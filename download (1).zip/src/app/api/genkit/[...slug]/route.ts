import { genkit } from 'genkit';
import { NextRequest } from 'next/server';

const handler = genkit.NextJSHandler();

export async function POST(req: NextRequest) {
  return handler(req);
}
