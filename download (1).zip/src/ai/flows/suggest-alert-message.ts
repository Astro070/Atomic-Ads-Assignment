'use server';

/**
 * @fileOverview This file defines a Genkit flow to generate alert message bodies from a prompt.
 *
 * - `generateAlertMessage` - An async function that takes a prompt and returns a generated alert message.
 * - `GenerateAlertMessageInput` - The input type for the generateAlertMessage function.
 * - `GenerateAlertMessageOutput` - The return type for the generateAlertMessage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateAlertMessageInputSchema = z.object({
  prompt: z
    .string()
    .describe('A prompt describing the alert and desired message body.'),
});
export type GenerateAlertMessageInput = z.infer<typeof GenerateAlertMessageInputSchema>;

const GenerateAlertMessageOutputSchema = z.object({
  messageBody: z
    .string()
    .describe('The generated message body for the alert.'),
});
export type GenerateAlertMessageOutput = z.infer<typeof GenerateAlertMessageOutputSchema>;

export async function generateAlertMessage(input: GenerateAlertMessageInput): Promise<GenerateAlertMessageOutput> {
  return generateAlertMessageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateAlertMessagePrompt',
  input: {schema: GenerateAlertMessageInputSchema},
  output: {schema: GenerateAlertMessageOutputSchema},
  prompt: `You are an expert at writing concise and effective alert messages.

  Based on the following prompt, generate a message body for an alert.

  Prompt: {{{prompt}}}

  Message Body:`,
});

const generateAlertMessageFlow = ai.defineFlow(
  {
    name: 'generateAlertMessageFlow',
    inputSchema: GenerateAlertMessageInputSchema,
    outputSchema: GenerateAlertMessageOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
