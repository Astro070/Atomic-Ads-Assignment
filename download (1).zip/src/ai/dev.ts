import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-alert-message.ts';
import '@/ai/flows/analyze-alert-engagement.ts';