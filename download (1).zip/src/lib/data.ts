import type { User, Team, Alert, UserAlertPreference } from '@/lib/types';

export const teams: Team[] = [
  { id: 'team-eng', name: 'Engineering' },
  { id: 'team-support', name: 'Support' },
  { id: 'team-marketing', name: 'Marketing' },
];

export const users: User[] = [
  { id: 'user-admin', name: 'Admin User', email: 'admin@atomicads.com', teamId: 'team-eng', role: 'Admin' },
  { id: 'user-1', name: 'Alice', email: 'alice@atomicads.com', teamId: 'team-eng', role: 'User' },
  { id: 'user-2', name: 'Bob', email: 'bob@atomicads.com', teamId: 'team-eng', role: 'User' },
  { id: 'user-3', name: 'Charlie', email: 'charlie@atomicads.com', teamId: 'team-support', role: 'User' },
  { id: 'user-4', name: 'Diana', email: 'diana@atomicads.com', teamId: 'team-marketing', role: 'User' },
];

export const alerts: Alert[] = [
  {
    id: 'alert-1',
    title: 'System Maintenance Scheduled',
    messageBody: 'A system-wide maintenance is scheduled for tonight at 2 AM UTC. Expect brief downtime.',
    severity: 'Info',
    deliveryType: 'InApp',
    startTime: new Date(Date.now() - 24 * 60 * 60 * 1000), // yesterday
    expiryTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // tomorrow
    reminderFrequency: 2,
    visibilityScope: 'Organization',
    visibilityTargets: [],
    status: 'active',
  },
  {
    id: 'alert-2',
    title: 'High CPU Usage Detected on Auth Service',
    messageBody: 'The authentication service is experiencing high CPU usage. The engineering team is investigating.',
    severity: 'Warning',
    deliveryType: 'InApp',
    startTime: new Date(),
    expiryTime: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
    reminderFrequency: 2,
    visibilityScope: 'Team',
    visibilityTargets: ['team-eng'],
    status: 'active',
  },
  {
    id: 'alert-3',
    title: 'Database Connection Lost',
    messageBody: 'Critical alert: The primary database is unreachable. All services are affected. Immediate action required.',
    severity: 'Critical',
    deliveryType: 'InApp',
    startTime: new Date(),
    expiryTime: new Date(Date.now() + 1 * 60 * 60 * 1000), // 1 hour from now
    reminderFrequency: 2,
    visibilityScope: 'Team',
    visibilityTargets: ['team-eng'],
    status: 'active',
  },
  {
    id: 'alert-4',
    title: 'Q3 Marketing Campaign Launch',
    messageBody: 'Reminder: The Q3 marketing campaign "Summer Splash" is set to launch tomorrow morning. Please review the final assets.',
    severity: 'Info',
    deliveryType: 'InApp',
    startTime: new Date(),
    expiryTime: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    reminderFrequency: 2,
    visibilityScope: 'Team',
    visibilityTargets: ['team-marketing'],
    status: 'active',
  },
  {
    id: 'alert-5',
    title: 'Review New Support Ticket Escalation Policy',
    messageBody: 'Please review the updated support ticket escalation policy by EOD.',
    severity: 'Info',
    deliveryType: 'InApp',
    startTime: new Date(),
    expiryTime: new Date(Date.now() + 24 * 60 * 60 * 1000),
    reminderFrequency: 2,
    visibilityScope: 'User',
    visibilityTargets: ['user-3'],
    status: 'active',
  },
  {
    id: 'alert-6',
    title: 'Archived: Old Security Patch Notice',
    messageBody: 'This is an old notice about a security patch that has been applied.',
    severity: 'Info',
    deliveryType: 'InApp',
    startTime: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    expiryTime: new Date(Date.now() - 28 * 24 * 60 * 60 * 1000),
    reminderFrequency: 2,
    visibilityScope: 'Organization',
    visibilityTargets: [],
    status: 'archived',
  },
];

export const userAlertPreferences: UserAlertPreference[] = [
    { userId: 'user-1', alertId: 'alert-1', readStatus: 'unread', snoozeStatus: false },
    { userId: 'user-2', alertId: 'alert-1', readStatus: 'read', snoozeStatus: false },
    { userId: 'user-1', alertId: 'alert-2', readStatus: 'unread', snoozeStatus: true, snoozeDate: new Date() },
    { userId: 'user-2', alertId: 'alert-2', readStatus: 'unread', snoozeStatus: false },
    { userId: 'user-3', alertId: 'alert-5', readStatus: 'unread', snoozeStatus: false },
];
