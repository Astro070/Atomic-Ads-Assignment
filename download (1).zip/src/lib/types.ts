export type User = {
  id: string;
  name: string;
  email: string;
  teamId: string;
  role: 'Admin' | 'User';
};

export type Team = {
  id: string;
  name: string;
};

export type AlertSeverity = 'Info' | 'Warning' | 'Critical';
export type AlertDeliveryType = 'InApp' | 'Email' | 'SMS';
export type AlertVisibilityScope = 'Organization' | 'Team' | 'User';
export type AlertStatus = 'active' | 'archived';

export type Alert = {
  id: string;
  title: string;
  messageBody: string;
  severity: AlertSeverity;
  deliveryType: AlertDeliveryType;
  startTime: Date;
  expiryTime: Date;
  reminderFrequency: number; // in hours
  visibilityScope: AlertVisibilityScope;
  visibilityTargets: string[]; // teamIds or userIds
  status: AlertStatus;
};

export type UserAlertPreference = {
  userId: string;
  alertId: string;
  readStatus: 'read' | 'unread';
  snoozeStatus: boolean;
  snoozeDate?: Date;
};

export type NotificationDelivery = {
  userId: string;
  alertId: string;
  deliveredAt: Date;
};
