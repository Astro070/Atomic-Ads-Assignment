'use client';

import { useState } from 'react';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Button } from '@/components/ui/button';
import { Icons } from '../shared/icons';
import { useToast } from '@/components/ui/use-toast';
import { analyzeAlertEngagement } from '@/ai/flows/analyze-alert-engagement';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { Loader2 } from 'lucide-react';

const chartData = [
  { severity: 'Info', count: 120 },
  { severity: 'Warning', count: 75 },
  { severity: 'Critical', count: 30 },
];

const chartConfig = {
  count: {
    label: 'Count',
    color: 'hsl(var(--primary))',
  },
} satisfies ChartConfig;

const engagementData = {
  totalAlertsCreated: 225,
  alertsDelivered: 200,
  alertsRead: 150,
  snoozeCounts: {
    'alert-1': 10,
    'alert-2': 45,
    'alert-3': 5,
  },
  severityBreakdown: {
    Info: 120,
    Warning: 75,
    Critical: 30,
  },
};

export function AnalyticsDashboard() {
  const { toast } = useToast();
  const [insights, setInsights] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setInsights('');
    try {
      const result = await analyzeAlertEngagement(engagementData);
      setInsights(result.insights);
      toast({
        title: 'Analysis Complete',
        description: 'Engagement insights have been generated successfully.',
      });
    } catch (error) {
      console.error('Analysis failed:', error);
      toast({
        variant: 'destructive',
        title: 'Analysis Failed',
        description: 'Could not generate engagement insights.',
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Alerts</CardTitle>
            <CardDescription>All alerts created</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{engagementData.totalAlertsCreated}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Delivery Rate</CardTitle>
            <CardDescription>Delivered vs. Created</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">
              {Math.round(
                (engagementData.alertsDelivered / engagementData.totalAlertsCreated) *
                  100
              )}
              %
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Read Rate</CardTitle>
            <CardDescription>Read vs. Delivered</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">
              {Math.round(
                (engagementData.alertsRead / engagementData.alertsDelivered) * 100
              )}
              %
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Total Snoozes</CardTitle>
            <CardDescription>Across all active alerts</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">
              {Object.values(engagementData.snoozeCounts).reduce(
                (a, b) => a + b,
                0
              )}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Alerts by Severity</CardTitle>
            <CardDescription>Breakdown of alerts by severity level</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[250px] w-full">
              <BarChart accessibilityLayer data={chartData}>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="severity"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={false}
                />
                 <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="count" fill="var(--color-count)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Engagement Analysis</CardTitle>
            <CardDescription>
              Use GenAI to analyze the current alert data and provide actionable insights.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {isAnalyzing && (
                <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
            )}
            {insights && (
              <Alert>
                <Icons.bot className="h-4 w-4" />
                <AlertTitle>AI Insights</AlertTitle>
                <AlertDescription className="whitespace-pre-wrap">
                  {insights}
                </AlertDescription>
              </Alert>
            )}
          </CardFooter>
          <CardFooter>
            <Button className="w-full" onClick={handleAnalyze} disabled={isAnalyzing}>
              <Icons.bot className="mr-2 h-4 w-4" />
              Analyze Engagement with AI
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
