'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/shared/icons';
import {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from '@/components/ui/tooltip';

export function AdminSidebar() {
  const pathname = usePathname();

  const navItems = [
    {
      href: '/admin/dashboard',
      label: 'Dashboard',
      icon: Icons.dashboard,
    },
    {
      href: '/admin/alerts',
      label: 'Alerts',
      icon: Icons.alerts,
    },
    {
      href: '/admin/analytics',
      label: 'Analytics',
      icon: Icons.analytics,
    },
  ];

  return (
    <aside className="sticky top-0 h-screen w-16 flex flex-col items-center border-r bg-card py-4 transition-all duration-300">
      <Link href="/admin" className="mb-6">
        <Icons.logo className="h-8 w-8 text-primary" />
        <span className="sr-only">AtomicAds DB Home</span>
      </Link>
      <nav className="flex flex-col items-center gap-2">
        <TooltipProvider>
          {navItems.map((item) => (
            <Tooltip key={item.href}>
              <TooltipTrigger asChild>
                <Button
                  asChild
                  variant={pathname === item.href ? 'secondary' : 'ghost'}
                  size="icon"
                  className={cn(
                    'rounded-lg',
                    pathname.startsWith(item.href) &&
                      item.href !== '/admin' &&
                      'text-primary',
                    pathname === item.href && 'text-primary'
                  )}
                >
                  <Link href={item.href}>
                    <item.icon className="h-5 w-5" />
                    <span className="sr-only">{item.label}</span>
                  </Link>
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">{item.label}</TooltipContent>
            </Tooltip>
          ))}
        </TooltipProvider>
      </nav>
    </aside>
  );
}
