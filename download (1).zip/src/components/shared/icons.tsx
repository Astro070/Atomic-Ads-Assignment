import type { LucideProps } from 'lucide-react';
import { Bot, BarChart, Bell, AlertTriangle, Info, ShieldAlert, LayoutDashboard } from 'lucide-react';

export const Icons = {
  logo: (props: LucideProps) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
    </svg>
  ),
  bot: Bot,
  analytics: BarChart,
  alerts: Bell,
  warning: AlertTriangle,
  info: Info,
  critical: ShieldAlert,
  dashboard: LayoutDashboard,
};
