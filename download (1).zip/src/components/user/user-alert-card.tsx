'use client';

import { useState } from 'react';
import type { Alert, AlertSeverity } from '@/lib/types';
import { cn } from '@/lib/utils';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/shared/icons';
import { useToast } from '@/components/ui/use-toast';
import { formatDistanceToNow } from 'date-fns';

const severityStyles: Record<
  AlertSeverity,
  { icon: React.FC<any>; classes: string }
> = {
  Info: {
    icon: Icons.info,
    classes: 'text-blue-500 border-blue-500/20 bg-blue-500/10',
  },
  Warning: {
    icon: Icons.warning,
    classes: 'text-yellow-500 border-yellow-500/20 bg-yellow-500/10',
  },
  Critical: {
    icon: Icons.critical,
    classes: 'text-red-500 border-red-500/20 bg-red-500/10',
  },
};

export function UserAlertCard({ alert }: { alert: Alert }) {
  const { toast } = useToast();
  const [isRead, setIsRead] = useState(false);
  const [isSnoozed, setIsSnoozed] = useState(false);

  const handleMarkAsRead = () => {
    setIsRead(true);
    toast({
      title: 'Alert Marked as Read',
      description: `"${alert.title}" has been marked as read.`,
    });
  };

  const handleSnooze = () => {
    setIsSnoozed(true);
    toast({
      title: 'Alert Snoozed',
      description: `"${alert.title}" has been snoozed for today.`,
    });
  };

  const SeverityIcon = severityStyles[alert.severity].icon;

  return (
    <Card
      className={cn(
        'flex flex-col transition-all',
        (isRead || isSnoozed) && 'opacity-60 bg-muted/50'
      )}
    >
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <CardTitle className="text-lg">{alert.title}</CardTitle>
            <CardDescription>
              {`Posted ${formatDistanceToNow(alert.startTime, { addSuffix: true })}`}
            </CardDescription>
          </div>
          <div
            className={cn(
              'flex h-8 w-8 items-center justify-center rounded-full border',
              severityStyles[alert.severity].classes
            )}
          >
            <SeverityIcon className="h-4 w-4" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground">{alert.messageBody}</p>
      </CardContent>
      <CardFooter className="flex gap-2">
        <Button
          variant="secondary"
          className="w-full"
          onClick={handleSnooze}
          disabled={isSnoozed || isRead}
        >
          {isSnoozed ? 'Snoozed' : 'Snooze'}
        </Button>
        <Button
          className="w-full"
          onClick={handleMarkAsRead}
          disabled={isRead || isSnoozed}
        >
          {isRead ? 'Read' : 'Mark as Read'}
        </Button>
      </CardFooter>
    </Card>
  );
}
