import type { Alert } from '@/lib/types';
import { UserAlertCard } from './user-alert-card';

export function UserAlertsList({ alerts }: { alerts: Alert[] }) {
  if (alerts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/30 bg-muted/20 p-12 text-center">
        <h3 className="text-xl font-semibold tracking-tight">All clear!</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          You have no active alerts right now.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {alerts.map((alert) => (
        <UserAlertCard key={alert.id} alert={alert} />
      ))}
    </div>
  );
}
